// ==UserScript==
// @name    VOP BannerClear
// @include    http://www.vop.co.kr/*
// ==/UserScript==

function clear(){
	document.getElementById('article_pop').style.display='none';
}
clear();